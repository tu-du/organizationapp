const cacheName = 'tudu-app';

const staticAssets = [
  './',
  './js/main.js',
  './css/main.css',
  './css/reset.css'
];

self.addEventListener('install', async function () {
  const cache = await caches.open(cacheName);
  cache.addAll(staticAssets);
});
