let homePage = `
  <h1 class="loginWelcome">Welcome Back!</h1>

  <h2 class="emailField">Email
    <input type="email" placeholder="Enter Email"></input>
  </h2>

  <h2 class="passwordField">Password
    <input type="password" placeholder="Enter Password"></input>
  </h2>

  <button class="loginButton"><a href="/tasks">Login</button></a>
`;

let tasksPage = `
  <h1>My Assignments</h1>

    <p class="addAssignment"><button class="button1"><a href="/newTask" style="text-decoration:none">+</button></p></a>


    **ASK ROCCO WHY HREF IS NOT WORKING HERE**
  <div class="list">
  <button type="button" class="block">
      <div class="listItem">
        <p class="dateDue">October 26</p>
        <p><a href="/checkTask" style="text-decoration:none">Interactive Systems Timeline</p>
        <div class="sublist">
          <p>High Priority</p>
          <p>30%</p>
          <p>Difficult</p>
        </div>
        <div class="bottomLine"></div>
      </div>
      </a>
    </button>

    // ** GREY LINE HERE IS NOT 100%**

      <button type="button" class="block">
        <div class="listItem">
          <p class="dateDue">November 2</p>
          <a href="/checkTask" style="text-decoration:none">Ergonomics Video Presentation</a>
          <div class="bottomLine"></div>
        </div>
      </button>

      <button type="button" class="block">
        <div class="listItem">
          <p class="dateDue">November 14</p>
          <a href="/checkTask" style="text-decoration:none">Portfolio Rough Draft Resume</a>
          <div class="bottomLine"></div>
        </div>
      </button>

  </div>
`;

let newTaskPage = `
  <div class="newTaskForm">
    <input type="text" class="taskName" placeholder="INPUT TASK NAME">

    <p class="formSectionTitle"></p>
    <div class="priority">
        <input type="text" class="taskName" placeholder="INPUT PERCENTAGE VALUE">
    </div>

    <p class="formSectionTitle">SELECT DIFFICULTY</p>
    <div class="difficulty">
      <input type="radio" class="select">Low</input>
      <input type="radio" class="select">Medium</input>
      <input type="radio" class="select">High</input>
    </div>

    <p class="formSectionTitle">SELECT PRIORITY</p>
    <div class="priority">
      <input type="radio" class="select">Low</input>
      <input type="radio" class="select">Medium</input>
      <input type="radio" class="select">High</input>
  </div>


    <p class="formSectionTitle">SELECT DEADLINE</p>

      <button class="createTaskButton"><a href="/tasks" style="text-decoration:none">CREATE TASK</button>

  </div>

`;


let navigationPage = `
  <div class="navMenu">
  <p class="closeMenu"><button class="button2"><a href="/tasks" style="text-decoration:none">Close</button></p></a>


  <div class="navSection">
    <h2>Pitch Presentation</h2>
    <p>Due Today</p>
    <p>9:00AM</p>
  </div>

  <div class="navSection">
    <h2>Tasks</h2>
  </div>

  <div class="navSection">
    <h2>Calendar</h2>
  </div>
  </div>
`;
